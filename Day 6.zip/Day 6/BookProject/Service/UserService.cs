﻿using BookProject.Models;
using BookProject.Service.IService;
using System.Collections.Generic;
using System.Linq;

namespace BookProject.Service
{
    public class UserService : IUserService
    {
        private readonly List<UserNew> _users = new()
        {
            new UserNew { Username = "admin", Password = "password", Role = "Admin" },
            new UserNew { Username = "user", Password = "password", Role = "User" }
        };

        // Adjust the return type to UserNew? to match the interface
        public UserNew? Authenticate(string username, string password)
        {
            return _users.SingleOrDefault(x => x.Username == username && x.Password == password);
        }

        public IEnumerable<UserNew> GetAll()
        {
            return _users;
        }
    }
}
