﻿using Microsoft.EntityFrameworkCore;
using BookProject.Models; // Ensure this is the correct namespace for your UserNew model

namespace BookProject.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<UserNew> Users { get; set; }
    }
}
